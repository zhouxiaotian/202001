import React from 'react';
import ReactDom from 'react-dom';
import My from './1_jsx';

ReactDom.render(<My/>,document.getElementById('root'))