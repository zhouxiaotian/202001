import React from 'react'

// jsx ：babel处理前的jsx语法
function My() {
  let a = '我很帅';
  return <h1>
    {a}
  </h1>
}
export default My