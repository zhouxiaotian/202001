import React from 'react';
import ReactDOM from 'react-dom';
class App extends React.Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //       count:100
    //     }
    // }
    state = {
      // 等同于 在 constructor中编写 this.state = {}
      count:100
    }
    add = ()=>{
      // 能够保证当前方法中的this是实例
      console.log("+") 
      console.log(this)
    }
    add2(){
      console.log(this)
    }
    minus(){
      console.log("-") 
      console.log(this)
    }
    render() {
        let {count} = this.state ;
        return <div className=''>
            当前数字是{count}
            {/* 
              在react中  事件使用的都是驼峰命名 
              <div onClick={对应的函数体}>
              我们一般把方法放到共有属性上；
            */}
            <button onClick={this.add}>+</button>

            {/* 
              当点击元素的时候  执行的是这个箭头函数；
              这个箭头函数中等个儿this是render中的this 
              通过this.add2() 执行 add2函数  那么 add2中的this 就成看点了
            */}
            <button onClick={()=>{this.add2()}}>+</button>


            <button  onClick={this.minus.bind(this)}>-</button>
        </div>;
    }
}

ReactDOM.render(<App/>,document.getElementById('root'))