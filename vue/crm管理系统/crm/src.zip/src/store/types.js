export const ADDCOUNT = 'addcount'
export const REOMOVECOUNT = 'removecount'
export const SETUSERINFO = 'setUserInfo'