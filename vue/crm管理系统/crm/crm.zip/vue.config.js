// 只是配置文件  每次修改 都要重新启动服务
module.exports = {
  lintOnSave:false
}